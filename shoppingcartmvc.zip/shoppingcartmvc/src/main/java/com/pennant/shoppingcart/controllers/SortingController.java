package com.pennant.shoppingcart.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.pennant.shoppingcart.DAL.ProductsDAL;
import com.pennant.shoppingcart.models.ProductListModel;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/test", loadOnStartup = 1)
public class SortingController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
		response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
		response.addHeader("Access-Control-Allow-Origin", "*");
		PrintWriter out = response.getWriter();
		response.setContentType("application/json");
		Integer category = Integer.parseInt(request.getParameter("categoryid"));
		ProductListModel products = new ProductsDAL().getProductById(category);
		try {
			JSONObject obj = new JSONObject();
			JSONArray id_Arr = new JSONArray();
			JSONArray name_Arr = new JSONArray();
			JSONArray image_Arr = new JSONArray();
			JSONArray price_Arr = new JSONArray();

			// Assuming getProductById() returns a list of ProductListModel
			// ProductListModel products = new ProductsDAL().getProductById(category);

			// Assuming ProductListModel has appropriate getters
			products.forEach((product) -> {
				id_Arr.put((Integer) product.getProd_Id()); // Cast to Integer if prod_Id is of type int
				name_Arr.put((String) product.getProd_Name()); // Cast to String if prod_Name is of type Object
				image_Arr.put((String) product.getProd_Image());// Cast to String if prod_Image is of type Object
				price_Arr.put((Double) product.getProd_Price());// Cast to Double if prod_Price is of type float or
																// Float
			});

			obj.put("product_id", id_Arr);
			obj.put("product_name", name_Arr);
			obj.put("product_image", image_Arr);
			obj.put("product_price", price_Arr);

			PrintWriter out1 = response.getWriter();
			out1.println(obj);
			out1.close();
		} catch (IOException | JSONException e) {
			e.printStackTrace(); // Handle the exception as per your application's requirements
		}

	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}

}
