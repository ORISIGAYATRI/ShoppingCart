package com.pennant.shoppingcart.DAL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.pennant.shoppingcart.models.SortingListModel;
import com.pennant.shoppingcart.models.SortingModel;

import JDBCUTILITIES.JdbcUtil;

public class SortingDal {
	private Connection con;
	private PreparedStatement psmt;
	private ResultSet rs;

	public SortingListModel getSorting() {
		SortingListModel sorting = new SortingListModel();
		con = JdbcUtil.getConnection();
		try {
			psmt = con.prepareStatement("select * from i213_product_category  ORDER BY product_name ASC;\r\n" + "");
			rs = psmt.executeQuery();
			while (rs.next()) {
				SortingModel sort = new SortingModel();
				sort.setCat_id(rs.getInt("p_cat_id"));
				sort.setCat_name(rs.getString("category_name"));
				sorting.add(sort);
			}
			JdbcUtil.closeConnections(con, psmt, rs);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sorting;
	}
}
